# Great Launcher — sajt

## Kako objaviti na GitHub Pages (besplatno, bez prijave za posetioce)

1. Idi na https://github.com i napravi besplatan nalog (ako ga nemaš).
2. Klikni **New repository**. Ime: `great-launcher` (može bilo šta). Izaberi **Public**.
3. Klikni **uploading an existing file** i prevuci `index.html` iz ovog foldera.
4. Klikni **Commit changes**.
5. Idi u **Settings → Pages** (levi meni).
6. Pod "Branch" izaberi `main` i folder `/ (root)`, pa **Save**.
7. Za 1-2 minuta dobićeš link tipa:
   `https://tvojusername.github.io/great-launcher/`

Taj link radi za svakoga, bez ičijeg naloga — ni GitHub ni Claude nalog nije potreban posetiocima.

## Kasnije izmene
Kad god želiš da promeniš sajt, otvori `index.html` na GitHubu, klikni olovčicu (Edit), izmeni, pa Commit — promene se vide odmah na linku.
